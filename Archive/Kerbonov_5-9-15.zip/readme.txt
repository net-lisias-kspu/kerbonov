uPDATE 5/15: fixed compatability with 1.0. Converted textures to .dds format. Some changes to file and folder names, so DEFINITELY delete any previous version of the SH_mods folder you've got installed or bad and weird stuff is very likely to happen.

UPDATE 7/14: 0.24 time; Adjusted prices to bring everything more in line with the stock parts.

UPDATE 5/14: Added three extra parts to pack, touched up some textures on KN2 internals, fixed nonworking sound effects on micro radial decoupler and RATO motor

License: CC 3.0 Share Alike with attribution
http://creativecommons.org/licenses/by-sa/3.0/