Original Mod By Sam Hall

Config retouching by Darkona (2016/01)

Released under CC 3.0 Share Alike with attribution